sudo rmmod rvd
