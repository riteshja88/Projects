sudo mkdir /media/rvd
sudo mount -t ext3 /dev/rvd /media/rvd
