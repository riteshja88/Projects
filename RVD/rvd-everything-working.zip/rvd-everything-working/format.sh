sudo mkfs -t ext3 /dev/rvd
