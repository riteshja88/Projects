sudo umount /dev/rvd
