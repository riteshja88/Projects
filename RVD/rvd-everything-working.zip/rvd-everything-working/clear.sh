sudo dmesg -c>0
sudo rm 0
